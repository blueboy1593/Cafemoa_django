import React, { Component } from 'react'
import LatteNavbar from '../headers/LatteNavbar';


export default class Main extends Component {
    render() {
        return (
            <div className= "main_indexPage">
                <LatteNavbar></LatteNavbar>
            </div>
        )
    }
}
